function subscribe() {
    alert("Thank you for subscribing to our newsletter!");
}
